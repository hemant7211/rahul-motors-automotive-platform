import { Search, Sun, Moon, Bell, LogOut } from "lucide-react";
import { useState } from "react";
import { useAuth } from "../../context/AuthContext";
import { useTheme } from "../../context/ThemeContext";
import { initials } from "../../lib/utils";
import { useNavigate } from "react-router-dom";

export function Topbar() {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <header className="flex h-16 items-center justify-between gap-4 border-b border-ink-200/60 dark:border-white/5 bg-white/60 dark:bg-ink-900/60 backdrop-blur-xl px-4 lg:px-6">
      <div className="flex items-center gap-3 flex-1 max-w-md">
        <div className="relative w-full">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-500/60" />
          <input
            type="text"
            placeholder="Search members, invoices, plans..."
            className="w-full h-9 rounded-xl border border-ink-200 dark:border-ink-700 bg-mist-50 dark:bg-ink-800 pl-9 pr-3 text-sm outline-none focus:border-signal-500 focus:ring-2 focus:ring-signal-500/20 transition-colors"
          />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={toggleTheme}
          aria-label="Toggle theme"
          className="flex h-9 w-9 items-center justify-center rounded-xl text-ink-600 dark:text-mist-200 hover:bg-ink-900/5 dark:hover:bg-white/5 transition-colors"
        >
          {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
        </button>
        <button
          aria-label="Notifications"
          className="relative flex h-9 w-9 items-center justify-center rounded-xl text-ink-600 dark:text-mist-200 hover:bg-ink-900/5 dark:hover:bg-white/5 transition-colors"
        >
          <Bell size={17} />
          <span className="absolute top-2 right-2 h-1.5 w-1.5 rounded-full bg-coral-500" />
        </button>

        <div className="relative">
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="flex items-center gap-2.5 rounded-xl pl-1 pr-2.5 py-1 hover:bg-ink-900/5 dark:hover:bg-white/5 transition-colors"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-signal-500 text-white text-xs font-semibold">
              {user ? initials(user.name) : "?"}
            </div>
            <div className="hidden sm:block text-left leading-tight">
              <p className="text-sm font-medium">{user?.name}</p>
              <p className="text-xs text-ink-500 dark:text-mist-200/50 capitalize">{user?.role.replace("_", " ")}</p>
            </div>
          </button>

          {menuOpen && (
            <div className="absolute right-0 mt-2 w-44 rounded-xl border border-ink-200 dark:border-ink-700 bg-white dark:bg-ink-800 shadow-soft dark:shadow-soft-dark py-1.5 z-20">
              <button
                onClick={handleLogout}
                className="flex w-full items-center gap-2 px-3.5 py-2 text-sm text-coral-600 hover:bg-coral-500/5 transition-colors"
              >
                <LogOut size={15} /> Log out
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
