import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  CreditCard,
  CalendarCheck,
  Dumbbell,
  Salad,
  Package,
  Receipt,
  Settings,
  Activity,
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { cn } from "../../lib/utils";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["super_admin", "gym_owner", "trainer", "receptionist", "member"] },
  { to: "/members", label: "Members", icon: Users, roles: ["super_admin", "gym_owner", "receptionist", "trainer"] },
  { to: "/plans", label: "Plans", icon: CreditCard, roles: ["super_admin", "gym_owner"] },
  { to: "/payments", label: "Payments", icon: Receipt, roles: ["super_admin", "gym_owner", "receptionist"] },
  { to: "/attendance", label: "Attendance", icon: CalendarCheck, roles: ["super_admin", "gym_owner", "receptionist", "trainer"] },
  { to: "/workouts", label: "Workouts", icon: Dumbbell, roles: ["gym_owner", "trainer", "member"] },
  { to: "/diet", label: "Diet Plans", icon: Salad, roles: ["gym_owner", "trainer", "member"] },
  { to: "/inventory", label: "Inventory", icon: Package, roles: ["super_admin", "gym_owner"] },
  { to: "/settings", label: "Settings", icon: Settings, roles: ["super_admin", "gym_owner"] },
];

export function Sidebar() {
  const { user } = useAuth();
  const visibleItems = navItems.filter((item) => !user || item.roles.includes(user.role));

  return (
    <aside className="hidden lg:flex w-64 shrink-0 flex-col border-r border-ink-200/60 dark:border-white/5 bg-white/60 dark:bg-ink-900/60 backdrop-blur-xl">
      <div className="flex items-center gap-2.5 px-6 h-16 border-b border-ink-200/60 dark:border-white/5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-signal-500 text-white">
          <Activity size={18} strokeWidth={2.5} />
        </div>
        <span className="font-display font-semibold text-lg tracking-tight">PulseGym</span>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
        {visibleItems.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-signal-500/10 text-signal-600 dark:text-signal-400"
                  : "text-ink-600 dark:text-mist-200 hover:bg-ink-900/5 dark:hover:bg-white/5"
              )
            }
          >
            <Icon size={18} strokeWidth={2} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 text-xs text-ink-500 dark:text-mist-200/40 border-t border-ink-200/60 dark:border-white/5">
        PulseGym ERP · v1.0
      </div>
    </aside>
  );
}
