import { useEffect, useState } from "react";
import { api } from "../lib/api";
import type { DashboardStats } from "../types";

interface ChartData {
  membershipGrowth: { _id: { year: number; month: number }; count: number }[];
  revenueTrend: { _id: { year: number; month: number }; total: number }[];
  planDistribution: { name: string; count: number }[];
  ageBuckets: { _id: number | string; count: number }[];
}

const MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function useDashboardData() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [charts, setCharts] = useState<ChartData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const load = async () => {
      try {
        const [statsRes, chartsRes] = await Promise.all([
          api.get("/dashboard/stats"),
          api.get("/dashboard/charts"),
        ]);
        setStats(statsRes.data.data);
        setCharts(chartsRes.data.data);
      } catch (err: any) {
        setError(err?.response?.data?.message || "Failed to load dashboard data.");
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, []);

  const revenueTrendData =
    charts?.revenueTrend.map((r) => ({ month: MONTH_LABELS[r._id.month - 1], revenue: r.total })) || [];
  const membershipGrowthData =
    charts?.membershipGrowth.map((m) => ({ month: MONTH_LABELS[m._id.month - 1], members: m.count })) || [];
  const planDistributionData = charts?.planDistribution || [];

  return { stats, revenueTrendData, membershipGrowthData, planDistributionData, isLoading, error };
}
