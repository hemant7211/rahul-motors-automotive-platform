import type { LucideIcon } from "lucide-react";
import { Card } from "../../components/ui/Card";

interface ModuleScaffoldProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

/**
 * Shared layout for modules whose data model exists on the backend but whose
 * dedicated UI is the next build phase. Keeps a consistent, intentional look
 * rather than a bare "coming soon" stub.
 */
export default function ModuleScaffold({ icon: Icon, title, description }: ModuleScaffoldProps) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        <p className="text-sm text-ink-500 dark:text-mist-200/60">{description}</p>
      </div>
      <Card className="flex flex-col items-center justify-center py-20 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-signal-500/10 text-signal-500 mb-4">
          <Icon size={24} />
        </div>
        <h3 className="font-semibold text-lg mb-1">This module is next up</h3>
        <p className="text-sm text-ink-500 dark:text-mist-200/60 max-w-sm">
          The data model and API for {title.toLowerCase()} are ready on the backend — this screen is scheduled for
          the next build phase.
        </p>
      </Card>
    </div>
  );
}
