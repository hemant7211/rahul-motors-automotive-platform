import { useEffect, useState } from "react";
import { Search, Plus, Users } from "lucide-react";
import { api } from "../../lib/api";
import type { Member } from "../../types";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Skeleton } from "../../components/ui/Skeleton";
import { formatDate, initials } from "../../lib/utils";

const STATUS_TONE: Record<string, "active" | "expired" | "frozen" | "blacklisted" | "cancelled"> = {
  active: "active",
  expired: "expired",
  frozen: "frozen",
  blacklisted: "blacklisted",
  cancelled: "cancelled",
};

export default function Members() {
  const [members, setMembers] = useState<Member[]>([]);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const timeout = setTimeout(async () => {
      setIsLoading(true);
      try {
        const { data } = await api.get("/members", { params: { q: query || undefined, status: statusFilter || undefined } });
        setMembers(data.data.members);
        setError(null);
      } catch (err: any) {
        setError(err?.response?.data?.message || "Failed to load members.");
      } finally {
        setIsLoading(false);
      }
    }, 300); // debounce search input

    return () => clearTimeout(timeout);
  }, [query, statusFilter]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Members</h1>
          <p className="text-sm text-ink-500 dark:text-mist-200/60">Manage member profiles, plans, and status.</p>
        </div>
        <Button>
          <Plus size={16} /> Add member
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-500/60" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, email, or phone..."
            className="w-full h-10 rounded-xl border border-ink-200 dark:border-ink-700 bg-white dark:bg-ink-800 pl-9 pr-3 text-sm outline-none focus:border-signal-500 focus:ring-2 focus:ring-signal-500/20"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="h-10 rounded-xl border border-ink-200 dark:border-ink-700 bg-white dark:bg-ink-800 px-3 text-sm outline-none focus:border-signal-500"
        >
          <option value="">All statuses</option>
          <option value="active">Active</option>
          <option value="expired">Expired</option>
          <option value="frozen">Frozen</option>
          <option value="blacklisted">Blacklisted</option>
        </select>
      </div>

      {error && <div className="rounded-xl bg-coral-500/10 text-coral-600 px-4 py-3 text-sm">{error}</div>}

      <div className="glass-panel rounded-xl2 overflow-hidden">
        {isLoading ? (
          <div className="p-5 space-y-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-14" />
            ))}
          </div>
        ) : members.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-6">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-signal-500/10 text-signal-500 mb-4">
              <Users size={24} />
            </div>
            <h3 className="font-semibold text-lg mb-1">No members yet</h3>
            <p className="text-sm text-ink-500 dark:text-mist-200/60 max-w-xs">
              Add your first member to start tracking attendance, payments, and progress.
            </p>
            <Button className="mt-5">
              <Plus size={16} /> Add member
            </Button>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-200/60 dark:border-white/5 text-left text-ink-500 dark:text-mist-200/50">
                <th className="px-5 py-3 font-medium">Member</th>
                <th className="px-5 py-3 font-medium">Membership ID</th>
                <th className="px-5 py-3 font-medium">Plan</th>
                <th className="px-5 py-3 font-medium">Joined</th>
                <th className="px-5 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {members.map((m) => (
                <tr
                  key={m._id}
                  className="border-b last:border-0 border-ink-200/40 dark:border-white/5 hover:bg-ink-900/[0.02] dark:hover:bg-white/[0.02] transition-colors"
                >
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-signal-500/10 text-signal-600 dark:text-signal-400 text-xs font-semibold">
                        {initials(m.name)}
                      </div>
                      <div>
                        <p className="font-medium">{m.name}</p>
                        <p className="text-xs text-ink-500 dark:text-mist-200/50">{m.email || m.phone}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-3 font-mono text-xs text-ink-600 dark:text-mist-200">{m.membershipId}</td>
                  <td className="px-5 py-3">{m.currentPlan?.name || "—"}</td>
                  <td className="px-5 py-3 text-ink-600 dark:text-mist-200">{formatDate(m.joiningDate)}</td>
                  <td className="px-5 py-3">
                    <Badge tone={STATUS_TONE[m.status]}>{m.status}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
