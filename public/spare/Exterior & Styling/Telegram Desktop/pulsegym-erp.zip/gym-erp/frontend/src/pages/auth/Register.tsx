import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Activity } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import toast from "react-hot-toast";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", gymName: "", email: "", password: "" });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await register({ ...form, role: "gym_owner" });
      toast.success("Account created! Check your email to verify.");
      navigate("/login");
    } catch (err: any) {
      toast.error(err?.response?.data?.message || "Registration failed.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-mist-50 dark:bg-ink-950 px-6 py-12">
      <div className="w-full max-w-sm animate-fadeUp">
        <div className="flex items-center gap-2.5 mb-10">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-signal-500 text-white">
            <Activity size={19} strokeWidth={2.5} />
          </div>
          <span className="font-display font-semibold text-xl">PulseGym</span>
        </div>

        <h1 className="text-2xl font-semibold mb-1">Start your 14-day free trial</h1>
        <p className="text-sm text-ink-500 dark:text-mist-200/60 mb-8">No credit card required.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Your name"
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <Input
            label="Gym name"
            required
            placeholder="e.g. Iron Temple Fitness"
            value={form.gymName}
            onChange={(e) => setForm({ ...form, gymName: e.target.value })}
          />
          <Input
            label="Email address"
            type="email"
            required
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
          <Input
            label="Password"
            type="password"
            required
            minLength={8}
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
          <Button type="submit" className="w-full" isLoading={isLoading}>
            Create account
          </Button>
        </form>

        <p className="text-center text-sm text-ink-500 dark:text-mist-200/60 mt-8">
          Already have an account?{" "}
          <Link to="/login" className="text-signal-500 hover:text-signal-600 font-medium">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
