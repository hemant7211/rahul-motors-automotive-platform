import { useEffect, useState, type FormEvent } from "react";
import { CalendarCheck, ScanLine } from "lucide-react";
import { api } from "../../lib/api";
import { Card } from "../../components/ui/Card";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import { Skeleton } from "../../components/ui/Skeleton";
import toast from "react-hot-toast";

interface AttendanceRecord {
  _id: string;
  checkInTime: string;
  method: string;
  member: { name: string; membershipId: string };
}

export default function Attendance() {
  const [membershipId, setMembershipId] = useState("");
  const [records, setRecords] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadRecords = () => {
    setIsLoading(true);
    api
      .get("/attendance")
      .then(({ data }) => setRecords(data.data.records))
      .finally(() => setIsLoading(false));
  };

  useEffect(loadRecords, []);

  const handleCheckIn = async (e: FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const { data } = await api.post("/attendance/check-in", { membershipId, method: "manual" });
      toast.success(`Checked in: ${data.data.member.name}`);
      setMembershipId("");
      loadRecords();
    } catch (err: any) {
      toast.error(err?.response?.data?.message || "Check-in failed.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Attendance</h1>
        <p className="text-sm text-ink-500 dark:text-mist-200/60">Scan or enter a membership ID to check members in.</p>
      </div>

      <Card className="max-w-lg">
        <form onSubmit={handleCheckIn} className="flex items-end gap-3">
          <div className="flex-1">
            <Input
              label="Membership ID"
              placeholder="e.g. GYM-4F2A9C"
              value={membershipId}
              onChange={(e) => setMembershipId(e.target.value.toUpperCase())}
              required
            />
          </div>
          <Button type="submit" isLoading={isSubmitting}>
            <ScanLine size={16} /> Check in
          </Button>
        </form>
      </Card>

      <div className="glass-panel rounded-xl2 overflow-hidden">
        <div className="px-5 py-3.5 border-b border-ink-200/60 dark:border-white/5 font-medium text-sm">Recent check-ins</div>
        {isLoading ? (
          <div className="p-5 space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-12" />
            ))}
          </div>
        ) : records.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center px-6">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-signal-500/10 text-signal-500 mb-4">
              <CalendarCheck size={24} />
            </div>
            <h3 className="font-semibold text-lg mb-1">No check-ins yet today</h3>
            <p className="text-sm text-ink-500 dark:text-mist-200/60 max-w-xs">
              Check-ins recorded via QR, barcode, or manual entry will show up here in real time.
            </p>
          </div>
        ) : (
          <ul className="divide-y divide-ink-200/40 dark:divide-white/5">
            {records.map((r) => (
              <li key={r._id} className="flex items-center justify-between px-5 py-3 text-sm">
                <div>
                  <p className="font-medium">{r.member.name}</p>
                  <p className="text-xs text-ink-500 dark:text-mist-200/50 font-mono">{r.member.membershipId}</p>
                </div>
                <div className="text-right">
                  <p className="text-ink-600 dark:text-mist-200">
                    {new Date(r.checkInTime).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                  </p>
                  <p className="text-xs text-ink-500 dark:text-mist-200/50 capitalize">{r.method.replace("_", " ")}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
