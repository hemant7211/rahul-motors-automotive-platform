import { Link } from "react-router-dom";
import { Compass } from "lucide-react";
import { Button } from "../../components/ui/Button";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-mist-50 dark:bg-ink-950 px-6 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-signal-500/10 text-signal-500 mb-5">
        <Compass size={24} />
      </div>
      <h1 className="text-3xl font-display font-semibold mb-2">Lost your way?</h1>
      <p className="text-sm text-ink-500 dark:text-mist-200/60 mb-6">This page doesn't exist. Let's get you back on track.</p>
      <Link to="/dashboard">
        <Button>Back to dashboard</Button>
      </Link>
    </div>
  );
}
