import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Card, CardHeader, CardTitle } from "../ui/Card";

interface Props {
  data: { month: string; members: number }[];
}

export function MembershipGrowthChart({ data }: Props) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Membership growth</CardTitle>
        <span className="text-xs text-ink-500 dark:text-mist-200/50">New joins / month</span>
      </CardHeader>
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data} margin={{ left: -20, right: 10, top: 10 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" className="text-ink-200 dark:text-ink-700" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="currentColor" className="text-ink-500" tickLine={false} axisLine={false} />
          <YAxis tick={{ fontSize: 12 }} stroke="currentColor" className="text-ink-500" tickLine={false} axisLine={false} />
          <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #E2E5EC", fontSize: 13 }} />
          <Bar dataKey="members" fill="#3FCE8A" radius={[6, 6, 0, 0]} maxBarSize={32} />
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
}
