import { type LucideIcon, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { Card } from "../ui/Card";
import { cn } from "../../lib/utils";

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  tone?: "signal" | "coral" | "pulse" | "amber";
  delta?: { value: string; positive: boolean };
}

const toneStyles = {
  signal: "bg-signal-500/10 text-signal-600 dark:text-signal-400",
  coral: "bg-coral-500/10 text-coral-600 dark:text-coral-400",
  pulse: "bg-pulse-500/10 text-pulse-600 dark:text-pulse-400",
  amber: "bg-amber-500/10 text-amber-500",
};

export function StatCard({ label, value, icon: Icon, tone = "signal", delta }: StatCardProps) {
  return (
    <Card className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-ink-500 dark:text-mist-200/60">{label}</span>
        <div className={cn("flex h-9 w-9 items-center justify-center rounded-xl", toneStyles[tone])}>
          <Icon size={17} strokeWidth={2} />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <span className="metric text-3xl font-semibold text-ink-900 dark:text-mist-50">{value}</span>
        {delta && (
          <span
            className={cn(
              "flex items-center gap-0.5 text-xs font-medium",
              delta.positive ? "text-pulse-600 dark:text-pulse-400" : "text-coral-500"
            )}
          >
            {delta.positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
            {delta.value}
          </span>
        )}
      </div>
    </Card>
  );
}
