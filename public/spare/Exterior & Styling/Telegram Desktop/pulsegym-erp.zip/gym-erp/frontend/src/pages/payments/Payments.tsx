import { useEffect, useState } from "react";
import { Receipt, Plus } from "lucide-react";
import { api } from "../../lib/api";
import type { Payment } from "../../types";
import { Badge } from "../../components/ui/Badge";
import { Button } from "../../components/ui/Button";
import { Skeleton } from "../../components/ui/Skeleton";
import { formatCurrency, formatDate } from "../../lib/utils";

const STATUS_TONE: Record<string, "active" | "warning" | "neutral" | "blacklisted"> = {
  paid: "active",
  pending: "warning",
  partial: "warning",
  refunded: "neutral",
};

export default function Payments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api
      .get("/payments")
      .then(({ data }) => setPayments(data.data.payments))
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Payments</h1>
          <p className="text-sm text-ink-500 dark:text-mist-200/60">Record payments and track invoices.</p>
        </div>
        <Button>
          <Plus size={16} /> Record payment
        </Button>
      </div>

      <div className="glass-panel rounded-xl2 overflow-hidden">
        {isLoading ? (
          <div className="p-5 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-14" />
            ))}
          </div>
        ) : payments.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center px-6">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-signal-500/10 text-signal-500 mb-4">
              <Receipt size={24} />
            </div>
            <h3 className="font-semibold text-lg mb-1">No payments recorded yet</h3>
            <p className="text-sm text-ink-500 dark:text-mist-200/60 max-w-xs">
              Payments you record for members will appear here with invoice numbers and status.
            </p>
          </div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-ink-200/60 dark:border-white/5 text-left text-ink-500 dark:text-mist-200/50">
                <th className="px-5 py-3 font-medium">Invoice</th>
                <th className="px-5 py-3 font-medium">Member</th>
                <th className="px-5 py-3 font-medium">Amount</th>
                <th className="px-5 py-3 font-medium">Method</th>
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p._id} className="border-b last:border-0 border-ink-200/40 dark:border-white/5">
                  <td className="px-5 py-3 font-mono text-xs">{p.invoiceNumber}</td>
                  <td className="px-5 py-3">{p.member?.name}</td>
                  <td className="px-5 py-3 metric">{formatCurrency(p.totalAmount)}</td>
                  <td className="px-5 py-3 capitalize">{p.method.replace("_", " ")}</td>
                  <td className="px-5 py-3 text-ink-600 dark:text-mist-200">{formatDate(p.paymentDate)}</td>
                  <td className="px-5 py-3">
                    <Badge tone={STATUS_TONE[p.status]}>{p.status}</Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
