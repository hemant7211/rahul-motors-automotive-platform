import { type HTMLAttributes } from "react";
import { cn } from "../../lib/utils";

type BadgeTone = "active" | "expired" | "frozen" | "blacklisted" | "cancelled" | "neutral" | "warning";

const toneStyles: Record<BadgeTone, string> = {
  active: "bg-pulse-500/10 text-pulse-600 dark:text-pulse-400 ring-1 ring-pulse-500/20",
  expired: "bg-ink-500/10 text-ink-600 dark:text-mist-200 ring-1 ring-ink-500/20",
  frozen: "bg-signal-500/10 text-signal-600 dark:text-signal-400 ring-1 ring-signal-500/20",
  blacklisted: "bg-coral-500/10 text-coral-600 dark:text-coral-400 ring-1 ring-coral-500/20",
  cancelled: "bg-ink-500/10 text-ink-500 ring-1 ring-ink-500/20",
  neutral: "bg-ink-100 dark:bg-ink-700 text-ink-700 dark:text-mist-100",
  warning: "bg-amber-500/10 text-amber-500 ring-1 ring-amber-500/20",
};

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: BadgeTone;
}

export function Badge({ className, tone = "neutral", ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium capitalize",
        toneStyles[tone],
        className
      )}
      {...props}
    />
  );
}
