import { useEffect, useState } from "react";
import { Plus, CreditCard } from "lucide-react";
import { api } from "../../lib/api";
import type { Plan } from "../../types";
import { Card } from "../../components/ui/Card";
import { Button } from "../../components/ui/Button";
import { Badge } from "../../components/ui/Badge";
import { Skeleton } from "../../components/ui/Skeleton";
import { formatCurrency } from "../../lib/utils";

export default function Plans() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    api
      .get("/plans")
      .then(({ data }) => setPlans(data.data.plans))
      .finally(() => setIsLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Membership plans</h1>
          <p className="text-sm text-ink-500 dark:text-mist-200/60">Create and manage the plans members subscribe to.</p>
        </div>
        <Button>
          <Plus size={16} /> New plan
        </Button>
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-48" />
          ))}
        </div>
      ) : plans.length === 0 ? (
        <Card className="flex flex-col items-center justify-center py-16 text-center">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-signal-500/10 text-signal-500 mb-4">
            <CreditCard size={24} />
          </div>
          <h3 className="font-semibold text-lg mb-1">No plans set up yet</h3>
          <p className="text-sm text-ink-500 dark:text-mist-200/60 max-w-xs mb-5">
            Create monthly, quarterly, or specialty plans like CrossFit or Yoga for members to subscribe to.
          </p>
          <Button>
            <Plus size={16} /> Create your first plan
          </Button>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {plans.map((plan) => (
            <Card key={plan._id} className="flex flex-col gap-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-display font-semibold text-lg">{plan.name}</h3>
                  <Badge tone="neutral" className="mt-1 capitalize">
                    {plan.category.replace("_", " ")}
                  </Badge>
                </div>
                {plan.discountPercent > 0 && <Badge tone="warning">{plan.discountPercent}% off</Badge>}
              </div>
              <div>
                <span className="metric text-3xl font-semibold">{formatCurrency(plan.finalPrice)}</span>
                <span className="text-sm text-ink-500 dark:text-mist-200/60"> / {plan.durationDays} days</span>
              </div>
              {plan.features?.length > 0 && (
                <ul className="text-sm text-ink-600 dark:text-mist-200 space-y-1.5">
                  {plan.features.slice(0, 4).map((f, i) => (
                    <li key={i} className="flex items-center gap-2">
                      <span className="h-1 w-1 rounded-full bg-pulse-500" /> {f}
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
