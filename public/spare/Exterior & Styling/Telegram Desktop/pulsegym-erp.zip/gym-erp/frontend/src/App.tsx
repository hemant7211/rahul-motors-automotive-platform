import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { Dumbbell, Salad, Package, Settings as SettingsIcon } from "lucide-react";

import { AuthProvider } from "./context/AuthContext";
import { ThemeProvider } from "./context/ThemeContext";
import { ProtectedRoute } from "./routes/ProtectedRoute";
import { DashboardLayout } from "./components/layout/DashboardLayout";

import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Dashboard from "./pages/dashboard/Dashboard";
import Members from "./pages/members/Members";
import Plans from "./pages/plans/Plans";
import Payments from "./pages/payments/Payments";
import Attendance from "./pages/attendance/Attendance";
import ModuleScaffold from "./pages/shared/ModuleScaffold";
import NotFound from "./pages/shared/NotFound";

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="top-right" toastOptions={{ style: { borderRadius: "12px", fontSize: "14px" } }} />
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route element={<ProtectedRoute />}>
              <Route element={<DashboardLayout />}>
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/members" element={<Members />} />
                <Route path="/plans" element={<Plans />} />
                <Route path="/payments" element={<Payments />} />
                <Route path="/attendance" element={<Attendance />} />
                <Route
                  path="/workouts"
                  element={<ModuleScaffold icon={Dumbbell} title="Workout plans" description="Assign and track exercise routines for members." />}
                />
                <Route
                  path="/diet"
                  element={<ModuleScaffold icon={Salad} title="Diet plans" description="Build meal plans with calorie and macro tracking." />}
                />
                <Route
                  path="/inventory"
                  element={<ModuleScaffold icon={Package} title="Inventory" description="Track supplements, equipment, and stock levels." />}
                />
                <Route
                  path="/settings"
                  element={<ModuleScaffold icon={SettingsIcon} title="Settings" description="Configure branding, taxes, and business hours." />}
                />
              </Route>
            </Route>

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
