export type Role = "super_admin" | "gym_owner" | "trainer" | "receptionist" | "member";

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: Role;
  gym: string | null;
  avatarUrl?: string;
  isEmailVerified: boolean;
}

export type MemberStatus = "active" | "expired" | "frozen" | "blacklisted" | "cancelled";

export interface Member {
  _id: string;
  membershipId: string;
  name: string;
  photoUrl?: string;
  gender?: "male" | "female" | "other";
  dob?: string;
  age?: number | null;
  bmi?: number | null;
  email?: string;
  phone?: string;
  height?: number;
  weight?: number;
  joiningDate: string;
  trainer?: { _id: string; name: string; email: string } | null;
  currentPlan?: { _id: string; name: string; durationDays: number; price: number } | null;
  membershipEndDate?: string;
  status: MemberStatus;
  lockerNumber?: string;
  notes?: string;
}

export interface Plan {
  _id: string;
  name: string;
  category: string;
  durationDays: number;
  price: number;
  discountPercent: number;
  finalPrice: number;
  features: string[];
  isActive: boolean;
}

export interface Payment {
  _id: string;
  invoiceNumber: string;
  member: { _id: string; name: string; membershipId: string };
  plan?: { _id: string; name: string };
  amount: number;
  totalAmount: number;
  amountPaid: number;
  amountDue: number;
  method: string;
  status: "paid" | "pending" | "partial" | "refunded";
  paymentDate: string;
}

export interface DashboardStats {
  totalMembers: number;
  activeMembers: number;
  todaysAttendance: number;
  expiringMemberships: number;
  newMembersThisMonth: number;
  monthlyRevenue: number;
  pendingPayments: number;
}

export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}
