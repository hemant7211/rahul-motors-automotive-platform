import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Card, CardHeader, CardTitle } from "../ui/Card";

interface Props {
  data: { name: string; count: number }[];
}

const COLORS = ["#2F6FFF", "#FF6B57", "#3FCE8A", "#F5A623", "#8B5CF6", "#EC4899"];

export function PlanDistributionChart({ data }: Props) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Plan distribution</CardTitle>
      </CardHeader>
      <ResponsiveContainer width="100%" height={260}>
        <PieChart>
          <Pie data={data} dataKey="count" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={3}>
            {data.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} stroke="none" />
            ))}
          </Pie>
          <Tooltip contentStyle={{ borderRadius: 12, border: "1px solid #E2E5EC", fontSize: 13 }} />
          <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
        </PieChart>
      </ResponsiveContainer>
    </Card>
  );
}
