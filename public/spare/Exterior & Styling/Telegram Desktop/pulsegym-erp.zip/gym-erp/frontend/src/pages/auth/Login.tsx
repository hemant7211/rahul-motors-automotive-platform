import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Activity, Eye, EyeOff } from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import { PulseDivider } from "../../components/ui/PulseDivider";
import toast from "react-hot-toast";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await login(email, password);
      toast.success("Welcome back.");
      navigate("/dashboard");
    } catch (err: any) {
      toast.error(err?.response?.data?.message || "Invalid email or password.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-2 bg-mist-50 dark:bg-ink-950">
      {/* Left: form */}
      <div className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm animate-fadeUp">
          <div className="flex items-center gap-2.5 mb-10">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-signal-500 text-white">
              <Activity size={19} strokeWidth={2.5} />
            </div>
            <span className="font-display font-semibold text-xl">PulseGym</span>
          </div>

          <h1 className="text-2xl font-semibold mb-1">Sign in to your dashboard</h1>
          <p className="text-sm text-ink-500 dark:text-mist-200/60 mb-8">
            Track members, revenue, and attendance in one place.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              id="email"
              label="Email address"
              type="email"
              placeholder="you@yourgym.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
            <div className="relative">
              <Input
                id="password"
                label="Password"
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute right-3 top-[38px] text-ink-500/60 hover:text-ink-700"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>

            <div className="flex justify-end">
              <Link to="/forgot-password" className="text-sm text-signal-500 hover:text-signal-600 font-medium">
                Forgot password?
              </Link>
            </div>

            <Button type="submit" className="w-full" isLoading={isLoading}>
              Sign in
            </Button>
          </form>

          <PulseDivider className="my-8" />

          <p className="text-center text-sm text-ink-500 dark:text-mist-200/60">
            New to PulseGym?{" "}
            <Link to="/register" className="text-signal-500 hover:text-signal-600 font-medium">
              Start your free trial
            </Link>
          </p>
        </div>
      </div>

      {/* Right: visual panel */}
      <div className="hidden lg:flex relative items-center justify-center overflow-hidden bg-ink-950">
        <div
          className="absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "radial-gradient(circle at 20% 20%, rgba(47,111,255,0.35), transparent 40%), radial-gradient(circle at 80% 70%, rgba(255,107,87,0.25), transparent 45%)",
          }}
        />
        <div className="relative z-10 max-w-md px-10 text-mist-50">
          <p className="text-xs uppercase tracking-widest text-signal-400 font-semibold mb-4">Built for gym operators</p>
          <h2 className="text-3xl font-display font-semibold leading-snug mb-4">
            Every member, every rep, every rupee — in one rhythm.
          </h2>
          <p className="text-mist-200/70 text-sm leading-relaxed">
            Manage attendance, memberships, payments, and trainer schedules from a single command center built for
            multi-location gyms.
          </p>
        </div>
      </div>
    </div>
  );
}
