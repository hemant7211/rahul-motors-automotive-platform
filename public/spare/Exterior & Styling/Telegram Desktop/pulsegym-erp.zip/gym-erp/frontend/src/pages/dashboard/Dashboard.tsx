import { Users, CalendarCheck, TrendingUp, Wallet, UserPlus, AlertCircle } from "lucide-react";
import { StatCard } from "../../components/dashboard/StatCard";
import { RevenueTrendChart } from "../../components/dashboard/RevenueTrendChart";
import { MembershipGrowthChart } from "../../components/dashboard/MembershipGrowthChart";
import { PlanDistributionChart } from "../../components/dashboard/PlanDistributionChart";
import { Skeleton } from "../../components/ui/Skeleton";
import { useDashboardData } from "../../hooks/useDashboardData";
import { formatCurrency } from "../../lib/utils";
import { useAuth } from "../../context/AuthContext";

export default function Dashboard() {
  const { user } = useAuth();
  const { stats, revenueTrendData, membershipGrowthData, planDistributionData, isLoading, error } =
    useDashboardData();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Good to see you, {user?.name?.split(" ")[0]}.</h1>
        <p className="text-sm text-ink-500 dark:text-mist-200/60">Here's how your gym is performing today.</p>
      </div>

      {error && (
        <div className="flex items-center gap-2 rounded-xl bg-coral-500/10 text-coral-600 px-4 py-3 text-sm">
          <AlertCircle size={16} /> {error}
        </div>
      )}

      {isLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Total members" value={String(stats?.totalMembers ?? 0)} icon={Users} tone="signal" />
          <StatCard
            label="Today's attendance"
            value={String(stats?.todaysAttendance ?? 0)}
            icon={CalendarCheck}
            tone="pulse"
          />
          <StatCard
            label="Monthly revenue"
            value={formatCurrency(stats?.monthlyRevenue ?? 0)}
            icon={Wallet}
            tone="signal"
          />
          <StatCard
            label="Expiring in 30 days"
            value={String(stats?.expiringMemberships ?? 0)}
            icon={AlertCircle}
            tone="amber"
          />
          <StatCard
            label="New members (month)"
            value={String(stats?.newMembersThisMonth ?? 0)}
            icon={UserPlus}
            tone="pulse"
          />
          <StatCard
            label="Pending payments"
            value={formatCurrency(stats?.pendingPayments ?? 0)}
            icon={TrendingUp}
            tone="coral"
          />
        </div>
      )}

      {isLoading ? (
        <div className="grid lg:grid-cols-2 gap-6">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
      ) : (
        <>
          <div className="grid lg:grid-cols-2 gap-6">
            <RevenueTrendChart data={revenueTrendData} />
            <MembershipGrowthChart data={membershipGrowthData} />
          </div>
          <div className="grid lg:grid-cols-2 gap-6">
            <PlanDistributionChart data={planDistributionData} />
          </div>
        </>
      )}
    </div>
  );
}
