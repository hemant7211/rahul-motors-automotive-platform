import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Card, CardHeader, CardTitle } from "../ui/Card";

interface Props {
  data: { month: string; revenue: number }[];
}

export function RevenueTrendChart({ data }: Props) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Revenue trend</CardTitle>
        <span className="text-xs text-ink-500 dark:text-mist-200/50">Last 6 months</span>
      </CardHeader>
      <ResponsiveContainer width="100%" height={260}>
        <AreaChart data={data} margin={{ left: -20, right: 10, top: 10 }}>
          <defs>
            <linearGradient id="revenueFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#2F6FFF" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#2F6FFF" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" className="text-ink-200 dark:text-ink-700" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="currentColor" className="text-ink-500" tickLine={false} axisLine={false} />
          <YAxis tick={{ fontSize: 12 }} stroke="currentColor" className="text-ink-500" tickLine={false} axisLine={false} />
          <Tooltip
            contentStyle={{ borderRadius: 12, border: "1px solid #E2E5EC", fontSize: 13 }}
            formatter={(value: number) => [`₹${value.toLocaleString("en-IN")}`, "Revenue"]}
          />
          <Area type="monotone" dataKey="revenue" stroke="#2F6FFF" strokeWidth={2.5} fill="url(#revenueFill)" />
        </AreaChart>
      </ResponsiveContainer>
    </Card>
  );
}
