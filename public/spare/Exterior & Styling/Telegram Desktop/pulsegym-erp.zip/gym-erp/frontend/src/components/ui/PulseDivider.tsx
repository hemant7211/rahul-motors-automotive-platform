import { cn } from "../../lib/utils";

/**
 * The signature visual motif for PulseGym: a heartbeat/rep-tempo line.
 * Used as a section divider and subtle loading indicator across the app.
 */
export function PulseDivider({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 400 24" className={cn("pulse-divider text-ink-300 dark:text-ink-600", className)} preserveAspectRatio="none">
      <path d="M0 12 H140 L152 2 L164 22 L176 12 H260 L272 4 L284 20 L296 12 H400" />
    </svg>
  );
}
