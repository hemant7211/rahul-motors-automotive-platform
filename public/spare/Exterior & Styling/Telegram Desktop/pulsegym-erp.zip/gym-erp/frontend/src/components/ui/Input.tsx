import { type InputHTMLAttributes, forwardRef } from "react";
import { cn } from "../../lib/utils";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className, label, error, id, ...props }, ref) => {
    return (
      <div className="flex flex-col gap-1.5">
        {label && (
          <label htmlFor={id} className="text-sm font-medium text-ink-700 dark:text-mist-200">
            {label}
          </label>
        )}
        <input
          ref={ref}
          id={id}
          className={cn(
            "h-11 rounded-xl border border-ink-200 dark:border-ink-600 bg-white dark:bg-ink-800 px-3.5 text-sm text-ink-900 dark:text-mist-50 placeholder:text-ink-500/50 focus:border-signal-500 focus:ring-2 focus:ring-signal-500/20 transition-colors outline-none",
            error && "border-coral-500 focus:border-coral-500 focus:ring-coral-500/20",
            className
          )}
          {...props}
        />
        {error && <span className="text-xs text-coral-500">{error}</span>}
      </div>
    );
  }
);
Input.displayName = "Input";
