/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        // Ink surfaces (dark mode base)
        ink: {
          950: "#0D0F14",
          900: "#14161C",
          800: "#1C1F27",
          700: "#262A35",
          600: "#343946",
          500: "#4A5163",
        },
        // Light mode base
        mist: {
          50: "#F7F8FA",
          100: "#EEF0F4",
          200: "#E2E5EC",
        },
        // Signal blue - primary
        signal: {
          400: "#5B8AFF",
          500: "#2F6FFF",
          600: "#1E56E0",
          700: "#1642AD",
        },
        // Coral - secondary / attention
        coral: {
          400: "#FF8A76",
          500: "#FF6B57",
          600: "#E5503C",
        },
        // Performance green - success / active status
        pulse: {
          400: "#6FE3A8",
          500: "#3FCE8A",
          600: "#2BA86E",
        },
        // Amber - warnings / expiring
        amber: {
          400: "#FFC24B",
          500: "#F5A623",
        },
      },
      fontFamily: {
        display: ["Space Grotesk", "sans-serif"],
        body: ["Inter", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        soft: "0 1px 2px rgba(13,15,20,0.04), 0 8px 24px -8px rgba(13,15,20,0.10)",
        "soft-dark": "0 1px 2px rgba(0,0,0,0.2), 0 8px 30px -8px rgba(0,0,0,0.5)",
        glow: "0 0 0 1px rgba(47,111,255,0.15), 0 8px 30px -8px rgba(47,111,255,0.35)",
      },
      keyframes: {
        pulseLine: {
          "0%, 100%": { strokeDashoffset: "0" },
          "50%": { strokeDashoffset: "40" },
        },
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(8px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
      animation: {
        pulseLine: "pulseLine 2.4s ease-in-out infinite",
        fadeUp: "fadeUp 0.4s ease-out both",
      },
    },
  },
  plugins: [],
};
