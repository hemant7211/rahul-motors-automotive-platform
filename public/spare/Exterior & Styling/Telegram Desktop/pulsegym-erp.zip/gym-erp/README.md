# PulseGym — Gym Membership Management System

A full-stack gym ERP: Node.js/Express/MongoDB backend + React/TypeScript/Tailwind frontend.

This is **Phase 1** of the build: authentication, multi-tenant gym structure, member
management, membership plans, payments, attendance, and an analytics dashboard —
built as real, working code (not placeholders). Workouts, diet plans, inventory, and
settings have their data models and routes scaffolded for the next phase but don't yet
have dedicated frontend screens (they show a clean "next up" state instead of a broken page).

## What's included

**Backend** (`/backend`)
- JWT auth with rotating refresh tokens (httpOnly cookies), OTP, email verification, password reset
- Role-based access control: `super_admin`, `gym_owner`, `trainer`, `receptionist`, `member`
- Multi-tenant data isolation (every gym's data is scoped by `gym` id)
- Models: User, Gym, Member, Plan, Payment, Attendance
- Member management: CRUD, search, filters, pagination, freeze/reactivate/blacklist, QR code generation
- Payment recording with auto-calculated GST/discount/dues, and membership auto-renewal on full payment
- Attendance check-in/out (manual now; QR/barcode/RFID payloads are already accepted by the same endpoint)
- Dashboard aggregation endpoints powering stat cards and charts (MongoDB aggregation pipelines)
- Security: helmet, rate limiting, mongo-sanitize, bcrypt, centralized error handling

**Frontend** (`/frontend`)
- React 19 + TypeScript + Vite + Tailwind CSS
- Custom design system ("performance-data" aesthetic — ink/signal-blue/coral, Space Grotesk + Inter + JetBrains Mono, glassmorphism cards, a signature "pulse line" motif)
- Dark/light mode, responsive sidebar + topbar shell
- Auth flow (login/register) wired to the backend, with automatic access-token refresh
- Dashboard with live stat cards + Recharts (revenue trend, membership growth, plan distribution)
- Members page (search, filter, status badges, empty/loading states)
- Payments and Attendance pages wired to their APIs

## Getting started

### 1. Backend

```bash
cd backend
cp .env.example .env      # fill in MONGO_URI, JWT secrets, SMTP creds (optional in dev)
npm install
npm run seed              # optional: creates a demo gym owner + members
npm run dev                # starts on http://localhost:5000
```

Demo login after seeding: `owner@pulsegym.demo` / `Password123!`

### 2. Frontend

```bash
cd frontend
cp .env.example .env       # set VITE_API_URL if not using the default
npm install
npm run dev                 # starts on http://localhost:5173
```

### 3. Docker (both services + MongoDB)

```bash
docker compose up --build
```

## Notes on scope and what to build next

This prompt originally asked for a huge feature set (workout/diet builders, inventory,
invoicing PDFs, SMS/WhatsApp automation, AI assistants, PWA, i18n, audit logs, and more).
Building all of that to a genuinely production-ready standard is a multi-week effort — so
this delivery focuses on a **solid, working core** (auth, members, plans, payments,
attendance, dashboard) with clean architecture that the rest can be built on top of:

- Trainer/Member portals (workout & diet plan builders)
- Invoice/receipt PDF generation
- Inventory & expense tracking
- Email/SMS/WhatsApp notification automation (cron jobs)
- Reports export (PDF/Excel/CSV)
- Super Admin cross-gym console

Each of these can be added as its own phase, reusing the same auth, layout, and design
system already in place.
