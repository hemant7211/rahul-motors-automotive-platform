import nodemailer from "nodemailer";

let transporter;

// Lazily creates the transporter so the app can boot even if SMTP env vars aren't set yet (e.g. local dev)
const getTransporter = () => {
  if (!transporter) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: Number(process.env.SMTP_PORT) === 465,
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }
  return transporter;
};

export const sendEmail = async ({ to, subject, text, html }) => {
  if (!process.env.SMTP_HOST) {
    console.warn(`[email] SMTP not configured — skipping send to ${to}: "${subject}"`);
    return;
  }
  await getTransporter().sendMail({
    from: process.env.EMAIL_FROM || "Gym ERP <no-reply@gymerp.com>",
    to,
    subject,
    text,
    html,
  });
};
