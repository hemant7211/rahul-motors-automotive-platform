import express from "express";
import { getStats, getChartData } from "../controllers/dashboardController.js";
import { protect, scopeToGym } from "../middleware/auth.js";

const router = express.Router();
router.use(protect, scopeToGym);

router.get("/stats", getStats);
router.get("/charts", getChartData);

export default router;
