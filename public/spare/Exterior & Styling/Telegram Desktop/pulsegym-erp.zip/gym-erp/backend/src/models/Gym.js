import mongoose from "mongoose";

const gymSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    logoUrl: { type: String, default: "" },
    address: { type: String, default: "" },
    phone: { type: String, default: "" },
    email: { type: String, default: "" },

    // Subscription (Super Admin controlled)
    subscriptionPlan: {
      type: String,
      enum: ["trial", "basic", "pro", "enterprise"],
      default: "trial",
    },
    subscriptionStatus: {
      type: String,
      enum: ["active", "expired", "cancelled"],
      default: "active",
    },
    subscriptionExpiresAt: { type: Date },

    // Branding / settings
    brandColor: { type: String, default: "#2563eb" },
    gstNumber: { type: String, default: "" },
    gstPercentage: { type: Number, default: 18 },
    currency: { type: String, default: "INR" },
    businessHours: {
      open: { type: String, default: "06:00" },
      close: { type: String, default: "22:00" },
    },

    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default mongoose.model("Gym", gymSchema);
