import mongoose from "mongoose";

const paymentSchema = new mongoose.Schema(
  {
    gym: { type: mongoose.Schema.Types.ObjectId, ref: "Gym", required: true },
    member: { type: mongoose.Schema.Types.ObjectId, ref: "Member", required: true },
    plan: { type: mongoose.Schema.Types.ObjectId, ref: "Plan" },
    recordedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },

    invoiceNumber: { type: String, unique: true },
    amount: { type: Number, required: true },
    gstAmount: { type: Number, default: 0 },
    discountAmount: { type: Number, default: 0 },
    totalAmount: { type: Number, required: true },

    method: {
      type: String,
      enum: ["cash", "upi", "credit_card", "debit_card", "net_banking", "wallet"],
      required: true,
    },
    status: {
      type: String,
      enum: ["paid", "pending", "partial", "refunded"],
      default: "paid",
    },
    amountPaid: { type: Number, default: 0 },
    amountDue: { type: Number, default: 0 },

    paymentDate: { type: Date, default: Date.now },
    notes: { type: String, default: "" },
  },
  { timestamps: true }
);

paymentSchema.index({ gym: 1, paymentDate: -1 });
paymentSchema.index({ member: 1 });

paymentSchema.pre("save", function (next) {
  if (!this.isNew || this.invoiceNumber) return next();
  const timestamp = Date.now().toString().slice(-8);
  this.invoiceNumber = `INV-${timestamp}`;
  next();
});

export default mongoose.model("Payment", paymentSchema);
