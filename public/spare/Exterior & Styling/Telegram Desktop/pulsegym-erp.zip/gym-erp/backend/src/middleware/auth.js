import jwt from "jsonwebtoken";
import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import User from "../models/User.js";

/**
 * Verifies the access token (sent as "Authorization: Bearer <token>"),
 * attaches the authenticated user to req.user, and checks the token
 * wasn't issued before the user's last password change.
 */
export const protect = asyncHandler(async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    throw new ApiError(401, "Not authenticated. Please log in.");
  }

  const token = authHeader.split(" ")[1];
  let decoded;
  try {
    decoded = jwt.verify(token, process.env.JWT_ACCESS_SECRET);
  } catch (err) {
    if (err.name === "TokenExpiredError") {
      throw new ApiError(401, "Access token expired.", { code: "TOKEN_EXPIRED" });
    }
    throw new ApiError(401, "Invalid access token.");
  }

  const user = await User.findById(decoded.id);
  if (!user || !user.isActive) {
    throw new ApiError(401, "User no longer exists or is deactivated.");
  }

  if (user.changedPasswordAfter(decoded.iat)) {
    throw new ApiError(401, "Password was changed recently. Please log in again.");
  }

  req.user = user;
  next();
});

/**
 * Role-based access control. Usage: restrictTo("gym_owner", "receptionist")
 */
export const restrictTo =
  (...roles) =>
  (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      throw new ApiError(403, "You do not have permission to perform this action.");
    }
    next();
  };

/**
 * Ensures multi-tenant data isolation: attaches the correct gym scope to the request.
 * Super admins may act across gyms (via req.query.gym); everyone else is scoped to their own gym.
 */
export const scopeToGym = (req, res, next) => {
  if (req.user.role === "super_admin") {
    req.gymId = req.query.gym || req.body.gym || null;
  } else {
    if (!req.user.gym) {
      throw new ApiError(403, "Your account is not associated with a gym yet.");
    }
    req.gymId = req.user.gym.toString();
  }
  next();
};
