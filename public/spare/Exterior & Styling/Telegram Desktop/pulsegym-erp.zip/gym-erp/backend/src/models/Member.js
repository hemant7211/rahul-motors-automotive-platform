import mongoose from "mongoose";
import crypto from "crypto";

const memberSchema = new mongoose.Schema(
  {
    gym: { type: mongoose.Schema.Types.ObjectId, ref: "Gym", required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // linked login account (optional until member self-registers)

    membershipId: { type: String, unique: true }, // human-readable ID, auto-generated
    qrCode: { type: String }, // data URL / cloudinary URL of QR image
    barcodeValue: { type: String },

    name: { type: String, required: true, trim: true },
    photoUrl: { type: String, default: "" },
    gender: { type: String, enum: ["male", "female", "other"] },
    dob: { type: Date },
    email: { type: String, trim: true, lowercase: true },
    phone: { type: String, trim: true },
    address: { type: String, default: "" },

    height: { type: Number }, // cm
    weight: { type: Number }, // kg
    medicalConditions: { type: String, default: "" },
    emergencyContact: {
      name: { type: String, default: "" },
      phone: { type: String, default: "" },
      relation: { type: String, default: "" },
    },

    joiningDate: { type: Date, default: Date.now },
    trainer: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    lockerNumber: { type: String, default: "" },
    notes: { type: String, default: "" },
    documents: [{ name: String, url: String, uploadedAt: { type: Date, default: Date.now } }],

    // Active membership plan subscription
    currentPlan: { type: mongoose.Schema.Types.ObjectId, ref: "Plan" },
    membershipStartDate: { type: Date },
    membershipEndDate: { type: Date },

    status: {
      type: String,
      enum: ["active", "expired", "frozen", "blacklisted", "cancelled"],
      default: "active",
    },
    freezeHistory: [
      {
        startDate: Date,
        endDate: Date,
        reason: String,
      },
    ],
    blacklistReason: { type: String, default: "" },
  },
  { timestamps: true }
);

memberSchema.index({ gym: 1, status: 1 });
memberSchema.index({ membershipId: 1 });
memberSchema.index({ name: "text", email: "text", phone: "text" });

// Virtual: age computed from DOB
memberSchema.virtual("age").get(function () {
  if (!this.dob) return null;
  const diff = Date.now() - this.dob.getTime();
  return Math.floor(diff / (365.25 * 24 * 60 * 60 * 1000));
});

// Virtual: BMI computed from height (cm) and weight (kg)
memberSchema.virtual("bmi").get(function () {
  if (!this.height || !this.weight) return null;
  const heightM = this.height / 100;
  return Number((this.weight / (heightM * heightM)).toFixed(1));
});

memberSchema.set("toJSON", { virtuals: true });

// Auto-generate a unique membership ID before saving new members
memberSchema.pre("save", function (next) {
  if (!this.isNew || this.membershipId) return next();
  const random = crypto.randomBytes(3).toString("hex").toUpperCase();
  this.membershipId = `GYM-${random}`;
  this.barcodeValue = this.membershipId;
  next();
});

export default mongoose.model("Member", memberSchema);
