import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import Payment from "../models/Payment.js";
import Member from "../models/Member.js";
import Plan from "../models/Plan.js";

export const listPayments = asyncHandler(async (req, res) => {
  const { member, status, page = 1, limit = 20 } = req.query;
  const filter = { gym: req.gymId };
  if (member) filter.member = member;
  if (status) filter.status = status;

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(100, Math.max(1, parseInt(limit)));

  const [payments, total] = await Promise.all([
    Payment.find(filter)
      .populate("member", "name membershipId")
      .populate("plan", "name")
      .sort("-paymentDate")
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum),
    Payment.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    data: { payments, pagination: { page: pageNum, limit: limitNum, total, totalPages: Math.ceil(total / limitNum) } },
  });
});

/**
 * POST /api/payments
 * Records a payment and, on full payment, extends/activates the member's plan dates.
 */
export const createPayment = asyncHandler(async (req, res) => {
  const { member: memberId, plan: planId, amount, gstAmount = 0, discountAmount = 0, amountPaid, method, notes } =
    req.body;

  const member = await Member.findOne({ _id: memberId, gym: req.gymId });
  if (!member) throw new ApiError(404, "Member not found.");

  const totalAmount = amount + gstAmount - discountAmount;
  const paid = amountPaid ?? totalAmount;
  const amountDue = Math.max(0, totalAmount - paid);
  const status = amountDue === 0 ? "paid" : paid === 0 ? "pending" : "partial";

  const payment = await Payment.create({
    gym: req.gymId,
    member: memberId,
    plan: planId,
    recordedBy: req.user._id,
    amount,
    gstAmount,
    discountAmount,
    totalAmount,
    amountPaid: paid,
    amountDue,
    method,
    status,
    notes,
  });

  // If fully paid and linked to a plan, (re)activate the member's membership window
  if (status === "paid" && planId) {
    const plan = await Plan.findById(planId);
    if (plan) {
      const start = member.membershipEndDate && member.membershipEndDate > new Date() ? member.membershipEndDate : new Date();
      member.currentPlan = plan._id;
      member.membershipStartDate = member.membershipStartDate || new Date();
      member.membershipEndDate = new Date(start.getTime() + plan.durationDays * 24 * 60 * 60 * 1000);
      member.status = "active";
      await member.save();
    }
  }

  res.status(201).json({ success: true, data: { payment } });
});

export const refundPayment = asyncHandler(async (req, res) => {
  const payment = await Payment.findOneAndUpdate(
    { _id: req.params.id, gym: req.gymId },
    { status: "refunded" },
    { new: true }
  );
  if (!payment) throw new ApiError(404, "Payment not found.");
  res.status(200).json({ success: true, data: { payment } });
});
