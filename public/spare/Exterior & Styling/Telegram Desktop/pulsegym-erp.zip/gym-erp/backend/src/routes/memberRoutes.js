import express from "express";
import {
  listMembers,
  getMember,
  createMember,
  updateMember,
  deleteMember,
  freezeMembership,
  reactivateMembership,
  blacklistMember,
} from "../controllers/memberController.js";
import { protect, restrictTo, scopeToGym } from "../middleware/auth.js";

const router = express.Router();

router.use(protect, scopeToGym);

router
  .route("/")
  .get(listMembers)
  .post(restrictTo("gym_owner", "receptionist", "super_admin"), createMember);

router
  .route("/:id")
  .get(getMember)
  .patch(restrictTo("gym_owner", "receptionist", "super_admin"), updateMember)
  .delete(restrictTo("gym_owner", "super_admin"), deleteMember);

router.patch("/:id/freeze", restrictTo("gym_owner", "receptionist"), freezeMembership);
router.patch("/:id/reactivate", restrictTo("gym_owner", "receptionist"), reactivateMembership);
router.patch("/:id/blacklist", restrictTo("gym_owner"), blacklistMember);

export default router;
