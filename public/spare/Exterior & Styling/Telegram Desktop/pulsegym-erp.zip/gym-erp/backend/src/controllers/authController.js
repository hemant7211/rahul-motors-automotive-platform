import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import User from "../models/User.js";
import Gym from "../models/Gym.js";
import {
  generateAccessToken,
  generateRefreshToken,
  hashToken,
  refreshTokenExpiryDate,
  setRefreshTokenCookie,
} from "../utils/tokens.js";
import { sendEmail } from "../utils/email.js";
import crypto from "crypto";

const MAX_ACTIVE_REFRESH_TOKENS = 5; // caps concurrent sessions per user

// Builds the safe user object returned to the client (never includes password/tokens)
const publicUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  role: user.role,
  gym: user.gym,
  avatarUrl: user.avatarUrl,
  isEmailVerified: user.isEmailVerified,
});

/**
 * POST /api/auth/register
 * Registers a new Gym Owner account (creates their Gym) OR a Member account (if invited/self-signup).
 */
export const register = asyncHandler(async (req, res) => {
  const { name, email, password, phone, role, gymName } = req.body;

  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) throw new ApiError(409, "An account with this email already exists.");

  // Public self-registration is only allowed for gym owners (starting a new gym) or members
  const allowedSelfSignupRoles = ["gym_owner", "member"];
  const finalRole = allowedSelfSignupRoles.includes(role) ? role : "gym_owner";

  const user = await User.create({ name, email, password, phone, role: finalRole });

  if (finalRole === "gym_owner") {
    const gym = await Gym.create({
      name: gymName || `${name}'s Gym`,
      owner: user._id,
      subscriptionPlan: "trial",
      subscriptionExpiresAt: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000), // 14-day trial
    });
    user.gym = gym._id;
    await user.save();
  }

  const verifyToken = user.createEmailVerificationToken();
  await user.save({ validateBeforeSave: false });

  const verifyUrl = `${process.env.CLIENT_URL}/verify-email/${verifyToken}`;
  await sendEmail({
    to: user.email,
    subject: "Verify your Gym ERP account",
    text: `Welcome to Gym ERP! Please verify your email by visiting: ${verifyUrl}`,
  }).catch((err) => console.error("Email send failed:", err.message)); // don't block registration on email failure

  res.status(201).json({
    success: true,
    message: "Account created. Please check your email to verify your account.",
    data: { user: publicUser(user) },
  });
});

/**
 * POST /api/auth/login
 * Authenticates a user, issues an access token (returned in body) and a refresh token (httpOnly cookie).
 */
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) throw new ApiError(400, "Email and password are required.");

  const user = await User.findOne({ email: email.toLowerCase() }).select("+password");
  if (!user || !(await user.comparePassword(password))) {
    throw new ApiError(401, "Invalid email or password.");
  }
  if (!user.isActive) throw new ApiError(403, "This account has been deactivated.");

  const accessToken = generateAccessToken(user);
  const refreshToken = generateRefreshToken();

  user.refreshTokens = (user.refreshTokens || [])
    .filter((rt) => rt.expiresAt > new Date()) // drop expired sessions
    .slice(-(MAX_ACTIVE_REFRESH_TOKENS - 1)); // cap concurrent sessions
  user.refreshTokens.push({
    tokenHash: hashToken(refreshToken),
    expiresAt: refreshTokenExpiryDate(),
    userAgent: req.headers["user-agent"] || "unknown",
  });
  user.lastLoginAt = new Date();
  await user.save({ validateBeforeSave: false });

  setRefreshTokenCookie(res, refreshToken);

  res.status(200).json({
    success: true,
    data: { user: publicUser(user), accessToken },
  });
});

/**
 * POST /api/auth/refresh
 * Rotates the refresh token: validates the cookie, issues a new access + refresh token pair.
 */
export const refresh = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken;
  if (!token) throw new ApiError(401, "No refresh token provided.");

  const tokenHash = hashToken(token);
  const user = await User.findOne({ "refreshTokens.tokenHash": tokenHash }).select("+refreshTokens.tokenHash");
  if (!user) throw new ApiError(401, "Invalid refresh token. Please log in again.");

  const storedToken = user.refreshTokens.find((rt) => rt.tokenHash === tokenHash);
  if (!storedToken || storedToken.expiresAt < new Date()) {
    throw new ApiError(401, "Refresh token expired. Please log in again.");
  }

  // Rotate: remove the used token, issue a new one (prevents replay attacks)
  user.refreshTokens = user.refreshTokens.filter((rt) => rt.tokenHash !== tokenHash);
  const newRefreshToken = generateRefreshToken();
  user.refreshTokens.push({
    tokenHash: hashToken(newRefreshToken),
    expiresAt: refreshTokenExpiryDate(),
    userAgent: req.headers["user-agent"] || "unknown",
  });
  await user.save({ validateBeforeSave: false });

  setRefreshTokenCookie(res, newRefreshToken);
  const accessToken = generateAccessToken(user);

  res.status(200).json({ success: true, data: { accessToken, user: publicUser(user) } });
});

/**
 * POST /api/auth/logout
 * Invalidates the current session's refresh token.
 */
export const logout = asyncHandler(async (req, res) => {
  const token = req.cookies?.refreshToken;
  if (token) {
    const tokenHash = hashToken(token);
    await User.updateOne({ "refreshTokens.tokenHash": tokenHash }, { $pull: { refreshTokens: { tokenHash } } });
  }
  res.clearCookie("refreshToken", { path: "/api/auth" });
  res.status(200).json({ success: true, message: "Logged out successfully." });
});

/**
 * GET /api/auth/me
 */
export const getMe = asyncHandler(async (req, res) => {
  res.status(200).json({ success: true, data: { user: publicUser(req.user) } });
});

/**
 * GET /api/auth/verify-email/:token
 */
export const verifyEmail = asyncHandler(async (req, res) => {
  const hashedToken = crypto.createHash("sha256").update(req.params.token).digest("hex");
  const user = await User.findOne({
    emailVerificationToken: hashedToken,
    emailVerificationExpires: { $gt: Date.now() },
  }).select("+emailVerificationToken +emailVerificationExpires");

  if (!user) throw new ApiError(400, "Verification link is invalid or has expired.");

  user.isEmailVerified = true;
  user.emailVerificationToken = undefined;
  user.emailVerificationExpires = undefined;
  await user.save({ validateBeforeSave: false });

  res.status(200).json({ success: true, message: "Email verified successfully." });
});

/**
 * POST /api/auth/forgot-password
 */
export const forgotPassword = asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: req.body.email?.toLowerCase() });
  // Always return success to avoid leaking which emails are registered
  if (!user) {
    return res.status(200).json({
      success: true,
      message: "If an account exists with that email, a reset link has been sent.",
    });
  }

  const resetToken = user.createPasswordResetToken();
  await user.save({ validateBeforeSave: false });

  const resetUrl = `${process.env.CLIENT_URL}/reset-password/${resetToken}`;
  await sendEmail({
    to: user.email,
    subject: "Reset your Gym ERP password",
    text: `You requested a password reset. Visit this link to set a new password (valid for 30 minutes): ${resetUrl}. If you didn't request this, ignore this email.`,
  }).catch((err) => console.error("Email send failed:", err.message));

  res.status(200).json({
    success: true,
    message: "If an account exists with that email, a reset link has been sent.",
  });
});

/**
 * POST /api/auth/reset-password/:token
 */
export const resetPassword = asyncHandler(async (req, res) => {
  const hashedToken = crypto.createHash("sha256").update(req.params.token).digest("hex");
  const user = await User.findOne({
    passwordResetToken: hashedToken,
    passwordResetExpires: { $gt: Date.now() },
  }).select("+passwordResetToken +passwordResetExpires");

  if (!user) throw new ApiError(400, "Reset link is invalid or has expired.");
  if (!req.body.password || req.body.password.length < 8) {
    throw new ApiError(400, "Password must be at least 8 characters.");
  }

  user.password = req.body.password;
  user.passwordResetToken = undefined;
  user.passwordResetExpires = undefined;
  user.refreshTokens = []; // invalidate all existing sessions after password reset
  await user.save();

  res.status(200).json({ success: true, message: "Password reset successfully. Please log in." });
});

/**
 * POST /api/auth/send-otp
 * Sends a 6-digit OTP to the user's registered email (SMS via Twilio can be wired in similarly).
 */
export const sendOtp = asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: req.body.email?.toLowerCase() });
  if (!user) throw new ApiError(404, "No account found with that email.");

  const otp = user.generateOtp();
  await user.save({ validateBeforeSave: false });

  await sendEmail({
    to: user.email,
    subject: "Your Gym ERP verification code",
    text: `Your one-time verification code is: ${otp}. It expires in 10 minutes.`,
  }).catch((err) => console.error("Email send failed:", err.message));

  res.status(200).json({ success: true, message: "OTP sent to registered email." });
});

/**
 * POST /api/auth/verify-otp
 */
export const verifyOtp = asyncHandler(async (req, res) => {
  const { email, otp } = req.body;
  const hashedOtp = crypto.createHash("sha256").update(otp || "").digest("hex");

  const user = await User.findOne({
    email: email?.toLowerCase(),
    otpCode: hashedOtp,
    otpExpires: { $gt: Date.now() },
  }).select("+otpCode +otpExpires");

  if (!user) throw new ApiError(400, "Invalid or expired OTP.");

  user.otpCode = undefined;
  user.otpExpires = undefined;
  user.isEmailVerified = true;
  await user.save({ validateBeforeSave: false });

  res.status(200).json({ success: true, message: "OTP verified successfully." });
});
