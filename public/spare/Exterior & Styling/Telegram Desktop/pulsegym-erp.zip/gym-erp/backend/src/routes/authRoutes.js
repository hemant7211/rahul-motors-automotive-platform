import express from "express";
import rateLimit from "express-rate-limit";
import {
  register,
  login,
  refresh,
  logout,
  getMe,
  verifyEmail,
  forgotPassword,
  resetPassword,
  sendOtp,
  verifyOtp,
} from "../controllers/authController.js";
import { protect } from "../middleware/auth.js";
import validate from "../middleware/validate.js";

const router = express.Router();

// Stricter rate limit on auth endpoints to slow down brute-force / credential-stuffing attempts
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  message: { success: false, message: "Too many attempts. Please try again later." },
  standardHeaders: true,
  legacyHeaders: false,
});

router.post(
  "/register",
  authLimiter,
  validate({
    name: { required: true, type: "string" },
    email: { required: true, type: "string" },
    password: { required: true, type: "string", minLength: 8 },
  }),
  register
);

router.post(
  "/login",
  authLimiter,
  validate({
    email: { required: true, type: "string" },
    password: { required: true, type: "string" },
  }),
  login
);

router.post("/refresh", refresh);
router.post("/logout", logout);
router.get("/me", protect, getMe);
router.get("/verify-email/:token", verifyEmail);

router.post("/forgot-password", authLimiter, forgotPassword);
router.post(
  "/reset-password/:token",
  authLimiter,
  validate({ password: { required: true, type: "string", minLength: 8 } }),
  resetPassword
);

router.post("/send-otp", authLimiter, sendOtp);
router.post("/verify-otp", authLimiter, verifyOtp);

export default router;
