import asyncHandler from "../utils/asyncHandler.js";
import Member from "../models/Member.js";
import Payment from "../models/Payment.js";
import Attendance from "../models/Attendance.js";

const startOfToday = () => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};

const monthsAgo = (n) => {
  const d = new Date();
  d.setMonth(d.getMonth() - n);
  d.setDate(1);
  d.setHours(0, 0, 0, 0);
  return d;
};

/**
 * GET /api/dashboard/stats
 * Returns the headline stat-card numbers.
 */
export const getStats = asyncHandler(async (req, res) => {
  const gym = req.gymId;
  const today = startOfToday();
  const in30Days = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  const startOfMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);

  const [
    totalMembers,
    activeMembers,
    todaysAttendance,
    expiringMemberships,
    newMembersThisMonth,
    revenueAgg,
    pendingPaymentsAgg,
  ] = await Promise.all([
    Member.countDocuments({ gym }),
    Member.countDocuments({ gym, status: "active" }),
    Attendance.countDocuments({ gym, checkInTime: { $gte: today } }),
    Member.countDocuments({
      gym,
      status: "active",
      membershipEndDate: { $gte: new Date(), $lte: in30Days },
    }),
    Member.countDocuments({ gym, joiningDate: { $gte: startOfMonth } }),
    Payment.aggregate([
      { $match: { gym, status: "paid", paymentDate: { $gte: startOfMonth } } },
      { $group: { _id: null, total: { $sum: "$totalAmount" } } },
    ]),
    Payment.aggregate([
      { $match: { gym, status: { $in: ["pending", "partial"] } } },
      { $group: { _id: null, total: { $sum: "$amountDue" } } },
    ]),
  ]);

  res.status(200).json({
    success: true,
    data: {
      totalMembers,
      activeMembers,
      todaysAttendance,
      expiringMemberships,
      newMembersThisMonth,
      monthlyRevenue: revenueAgg[0]?.total || 0,
      pendingPayments: pendingPaymentsAgg[0]?.total || 0,
    },
  });
});

/**
 * GET /api/dashboard/charts
 * Returns time-series and distribution data for the dashboard charts.
 */
export const getChartData = asyncHandler(async (req, res) => {
  const gym = req.gymId;
  const sixMonthsAgo = monthsAgo(5);

  const [membershipGrowth, revenueTrend, attendanceTrend, planDistribution, ageBuckets] = await Promise.all([
    // Membership growth: new members per month, last 6 months
    Member.aggregate([
      { $match: { gym, joiningDate: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { year: { $year: "$joiningDate" }, month: { $month: "$joiningDate" } },
          count: { $sum: 1 },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1 } },
    ]),
    // Revenue trend: total paid per month, last 6 months
    Payment.aggregate([
      { $match: { gym, status: "paid", paymentDate: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id: { year: { $year: "$paymentDate" }, month: { $month: "$paymentDate" } },
          total: { $sum: "$totalAmount" },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1 } },
    ]),
    // Attendance trend: check-ins per day, last 30 days
    Attendance.aggregate([
      { $match: { gym, checkInTime: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } } },
      {
        $group: {
          _id: { year: { $year: "$checkInTime" }, month: { $month: "$checkInTime" }, day: { $dayOfMonth: "$checkInTime" } },
          count: { $sum: 1 },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1, "_id.day": 1 } },
    ]),
    // Plan distribution (pie chart)
    Member.aggregate([
      { $match: { gym, currentPlan: { $ne: null } } },
      { $group: { _id: "$currentPlan", count: { $sum: 1 } } },
      { $lookup: { from: "plans", localField: "_id", foreignField: "_id", as: "plan" } },
      { $unwind: "$plan" },
      { $project: { name: "$plan.name", count: 1, _id: 0 } },
    ]),
    // Age distribution buckets
    Member.aggregate([
      { $match: { gym, dob: { $ne: null } } },
      {
        $project: {
          age: {
            $floor: { $divide: [{ $subtract: [new Date(), "$dob"] }, 1000 * 60 * 60 * 24 * 365.25] },
          },
        },
      },
      {
        $bucket: {
          groupBy: "$age",
          boundaries: [0, 18, 25, 35, 45, 55, 65, 120],
          default: "unknown",
          output: { count: { $sum: 1 } },
        },
      },
    ]),
  ]);

  res.status(200).json({
    success: true,
    data: { membershipGrowth, revenueTrend, attendanceTrend, planDistribution, ageBuckets },
  });
});
