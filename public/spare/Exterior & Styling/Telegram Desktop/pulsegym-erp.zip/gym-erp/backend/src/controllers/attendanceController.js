import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import Attendance from "../models/Attendance.js";
import Member from "../models/Member.js";

/**
 * POST /api/attendance/check-in
 * Marks a member present. Accepts membershipId (from QR/barcode scan) or member ObjectId.
 */
export const checkIn = asyncHandler(async (req, res) => {
  const { membershipId, memberId, method = "manual" } = req.body;

  const member = memberId
    ? await Member.findOne({ _id: memberId, gym: req.gymId })
    : await Member.findOne({ membershipId, gym: req.gymId });

  if (!member) throw new ApiError(404, "Member not found.");
  if (member.status === "blacklisted") throw new ApiError(403, "This member is blacklisted.");
  if (member.status === "frozen") throw new ApiError(403, "This membership is currently frozen.");

  const attendance = await Attendance.create({
    gym: req.gymId,
    member: member._id,
    method,
    markedBy: req.user?._id,
  });

  res.status(201).json({ success: true, data: { attendance, member: { name: member.name, membershipId: member.membershipId } } });
});

export const checkOut = asyncHandler(async (req, res) => {
  const attendance = await Attendance.findOneAndUpdate(
    { _id: req.params.id, gym: req.gymId },
    { checkOutTime: new Date() },
    { new: true }
  );
  if (!attendance) throw new ApiError(404, "Attendance record not found.");
  res.status(200).json({ success: true, data: { attendance } });
});

export const listAttendance = asyncHandler(async (req, res) => {
  const { member, from, to, page = 1, limit = 50 } = req.query;
  const filter = { gym: req.gymId };
  if (member) filter.member = member;
  if (from || to) {
    filter.checkInTime = {};
    if (from) filter.checkInTime.$gte = new Date(from);
    if (to) filter.checkInTime.$lte = new Date(to);
  }

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(200, Math.max(1, parseInt(limit)));

  const [records, total] = await Promise.all([
    Attendance.find(filter)
      .populate("member", "name membershipId photoUrl")
      .sort("-checkInTime")
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum),
    Attendance.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    data: { records, pagination: { page: pageNum, limit: limitNum, total, totalPages: Math.ceil(total / limitNum) } },
  });
});
