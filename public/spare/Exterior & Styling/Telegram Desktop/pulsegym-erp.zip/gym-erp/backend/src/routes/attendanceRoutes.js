import express from "express";
import { checkIn, checkOut, listAttendance } from "../controllers/attendanceController.js";
import { protect, restrictTo, scopeToGym } from "../middleware/auth.js";

const router = express.Router();
router.use(protect, scopeToGym);

router.get("/", listAttendance);
router.post("/check-in", restrictTo("gym_owner", "receptionist", "trainer"), checkIn);
router.patch("/:id/check-out", restrictTo("gym_owner", "receptionist", "trainer"), checkOut);

export default router;
