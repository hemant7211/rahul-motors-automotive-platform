import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import Member from "../models/Member.js";
import QRCode from "qrcode";

/**
 * GET /api/members
 * Supports search (?q=), status filter, trainer filter, pagination, sorting.
 */
export const listMembers = asyncHandler(async (req, res) => {
  const { q, status, trainer, plan, page = 1, limit = 20, sortBy = "-createdAt" } = req.query;

  const filter = { gym: req.gymId };
  if (status) filter.status = status;
  if (trainer) filter.trainer = trainer;
  if (plan) filter.currentPlan = plan;
  if (q) filter.$text = { $search: q };

  const pageNum = Math.max(1, parseInt(page));
  const limitNum = Math.min(100, Math.max(1, parseInt(limit)));

  const [members, total] = await Promise.all([
    Member.find(filter)
      .populate("trainer", "name email")
      .populate("currentPlan", "name durationDays price")
      .sort(sortBy)
      .skip((pageNum - 1) * limitNum)
      .limit(limitNum),
    Member.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    data: {
      members,
      pagination: { page: pageNum, limit: limitNum, total, totalPages: Math.ceil(total / limitNum) },
    },
  });
});

export const getMember = asyncHandler(async (req, res) => {
  const member = await Member.findOne({ _id: req.params.id, gym: req.gymId })
    .populate("trainer", "name email")
    .populate("currentPlan");
  if (!member) throw new ApiError(404, "Member not found.");
  res.status(200).json({ success: true, data: { member } });
});

export const createMember = asyncHandler(async (req, res) => {
  const member = await Member.create({ ...req.body, gym: req.gymId });

  // Generate a QR code encoding the membership ID for check-in scanning
  const qrDataUrl = await QRCode.toDataURL(member.membershipId);
  member.qrCode = qrDataUrl;
  await member.save();

  res.status(201).json({ success: true, data: { member } });
});

export const updateMember = asyncHandler(async (req, res) => {
  const member = await Member.findOneAndUpdate({ _id: req.params.id, gym: req.gymId }, req.body, {
    new: true,
    runValidators: true,
  });
  if (!member) throw new ApiError(404, "Member not found.");
  res.status(200).json({ success: true, data: { member } });
});

export const deleteMember = asyncHandler(async (req, res) => {
  const member = await Member.findOneAndDelete({ _id: req.params.id, gym: req.gymId });
  if (!member) throw new ApiError(404, "Member not found.");
  res.status(200).json({ success: true, message: "Member deleted successfully." });
});

export const freezeMembership = asyncHandler(async (req, res) => {
  const { endDate, reason } = req.body;
  const member = await Member.findOne({ _id: req.params.id, gym: req.gymId });
  if (!member) throw new ApiError(404, "Member not found.");

  member.status = "frozen";
  member.freezeHistory.push({ startDate: new Date(), endDate, reason });
  await member.save();

  res.status(200).json({ success: true, data: { member } });
});

export const reactivateMembership = asyncHandler(async (req, res) => {
  const member = await Member.findOne({ _id: req.params.id, gym: req.gymId });
  if (!member) throw new ApiError(404, "Member not found.");

  member.status = "active";
  await member.save();

  res.status(200).json({ success: true, data: { member } });
});

export const blacklistMember = asyncHandler(async (req, res) => {
  const member = await Member.findOne({ _id: req.params.id, gym: req.gymId });
  if (!member) throw new ApiError(404, "Member not found.");

  member.status = "blacklisted";
  member.blacklistReason = req.body.reason || "";
  await member.save();

  res.status(200).json({ success: true, data: { member } });
});
