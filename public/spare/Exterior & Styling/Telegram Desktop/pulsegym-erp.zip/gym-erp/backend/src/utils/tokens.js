import jwt from "jsonwebtoken";
import crypto from "crypto";

export const generateAccessToken = (user) =>
  jwt.sign({ id: user._id, role: user.role, gym: user.gym }, process.env.JWT_ACCESS_SECRET, {
    expiresIn: process.env.JWT_ACCESS_EXPIRES || "15m",
  });

export const generateRefreshToken = () => crypto.randomBytes(40).toString("hex");

export const hashToken = (token) => crypto.createHash("sha256").update(token).digest("hex");

export const refreshTokenExpiryDate = () => {
  const days = parseInt(process.env.JWT_REFRESH_EXPIRES) || 7;
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
};

/**
 * Sets the refresh token as an httpOnly cookie.
 * httpOnly + sameSite=strict + secure(prod) protects against XSS/CSRF token theft.
 */
export const setRefreshTokenCookie = (res, token) => {
  res.cookie("refreshToken", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    maxAge: (parseInt(process.env.JWT_REFRESH_EXPIRES) || 7) * 24 * 60 * 60 * 1000,
    path: "/api/auth",
  });
};
