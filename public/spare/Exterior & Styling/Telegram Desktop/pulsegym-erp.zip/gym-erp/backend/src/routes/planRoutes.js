import express from "express";
import { listPlans, createPlan, updatePlan, deletePlan } from "../controllers/planController.js";
import { protect, restrictTo, scopeToGym } from "../middleware/auth.js";

const router = express.Router();
router.use(protect, scopeToGym);

router.route("/").get(listPlans).post(restrictTo("gym_owner", "super_admin"), createPlan);
router
  .route("/:id")
  .patch(restrictTo("gym_owner", "super_admin"), updatePlan)
  .delete(restrictTo("gym_owner", "super_admin"), deletePlan);

export default router;
