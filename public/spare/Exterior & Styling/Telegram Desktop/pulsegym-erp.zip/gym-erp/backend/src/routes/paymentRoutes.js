import express from "express";
import { listPayments, createPayment, refundPayment } from "../controllers/paymentController.js";
import { protect, restrictTo, scopeToGym } from "../middleware/auth.js";

const router = express.Router();
router.use(protect, scopeToGym);

router.route("/").get(listPayments).post(restrictTo("gym_owner", "receptionist"), createPayment);
router.patch("/:id/refund", restrictTo("gym_owner"), refundPayment);

export default router;
