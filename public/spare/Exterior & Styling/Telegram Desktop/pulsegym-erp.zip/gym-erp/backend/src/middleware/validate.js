import ApiError from "../utils/ApiError.js";

/**
 * Lightweight schema-based validator. Pass a rules object like:
 * { email: { required: true, type: "string" }, password: { required: true, minLength: 8 } }
 * Keeps the project dependency-light while still centralizing validation logic.
 */
const validate = (rules) => (req, res, next) => {
  const errors = [];

  for (const [field, rule] of Object.entries(rules)) {
    const value = req.body[field];

    if (rule.required && (value === undefined || value === null || value === "")) {
      errors.push(`${field} is required.`);
      continue;
    }
    if (value === undefined || value === null || value === "") continue;

    if (rule.type === "string" && typeof value !== "string") {
      errors.push(`${field} must be a string.`);
    }
    if (rule.type === "number" && typeof value !== "number") {
      errors.push(`${field} must be a number.`);
    }
    if (rule.minLength && String(value).length < rule.minLength) {
      errors.push(`${field} must be at least ${rule.minLength} characters.`);
    }
    if (rule.enum && !rule.enum.includes(value)) {
      errors.push(`${field} must be one of: ${rule.enum.join(", ")}.`);
    }
    if (rule.pattern && !rule.pattern.test(value)) {
      errors.push(`${field} is not in a valid format.`);
    }
  }

  if (errors.length) throw new ApiError(400, "Validation failed", errors);
  next();
};

export default validate;
