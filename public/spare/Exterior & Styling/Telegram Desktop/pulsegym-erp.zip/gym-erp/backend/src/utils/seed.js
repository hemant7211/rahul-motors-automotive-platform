// Seeds a demo gym owner, plans, and a couple of members so the app is testable immediately.
// Run with: npm run seed
import dotenv from "dotenv";
dotenv.config();

import mongoose from "mongoose";
import connectDB from "../config/db.js";
import User from "../models/User.js";
import Gym from "../models/Gym.js";
import Plan from "../models/Plan.js";
import Member from "../models/Member.js";

const seed = async () => {
  await connectDB();
  console.log("Seeding demo data...");

  await Promise.all([User.deleteMany({}), Gym.deleteMany({}), Plan.deleteMany({}), Member.deleteMany({})]);

  const owner = await User.create({
    name: "Rohan Mehta",
    email: "owner@pulsegym.demo",
    password: "Password123!",
    role: "gym_owner",
    isEmailVerified: true,
  });

  const gym = await Gym.create({
    name: "Iron Temple Fitness",
    owner: owner._id,
    subscriptionPlan: "pro",
    subscriptionExpiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
  });

  owner.gym = gym._id;
  await owner.save();

  const plans = await Plan.insertMany([
    { gym: gym._id, name: "Monthly Unlimited", category: "general", durationDays: 30, price: 2000, features: ["Unlimited gym access", "Locker included"] },
    { gym: gym._id, name: "Quarterly Unlimited", category: "general", durationDays: 90, price: 5400, discountPercent: 10, features: ["Unlimited gym access", "1 free PT session"] },
    { gym: gym._id, name: "CrossFit Intensive", category: "crossfit", durationDays: 30, price: 3500, features: ["CrossFit classes", "Nutrition consult"] },
  ]);

  await Member.insertMany([
    {
      gym: gym._id,
      name: "Aditi Sharma",
      email: "aditi@example.com",
      phone: "9876543210",
      gender: "female",
      dob: new Date("1996-04-12"),
      height: 165,
      weight: 58,
      joiningDate: new Date(),
      currentPlan: plans[0]._id,
      membershipStartDate: new Date(),
      membershipEndDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      status: "active",
    },
    {
      gym: gym._id,
      name: "Karan Verma",
      email: "karan@example.com",
      phone: "9123456780",
      gender: "male",
      dob: new Date("1990-11-02"),
      height: 178,
      weight: 82,
      joiningDate: new Date(),
      currentPlan: plans[1]._id,
      membershipStartDate: new Date(),
      membershipEndDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      status: "active",
    },
  ]);

  console.log("Seed complete.");
  console.log("Login with: owner@pulsegym.demo / Password123!");
  await mongoose.disconnect();
  process.exit(0);
};

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
