import mongoose from "mongoose";

const attendanceSchema = new mongoose.Schema(
  {
    gym: { type: mongoose.Schema.Types.ObjectId, ref: "Gym", required: true },
    member: { type: mongoose.Schema.Types.ObjectId, ref: "Member", required: true },
    checkInTime: { type: Date, required: true, default: Date.now },
    checkOutTime: { type: Date },
    method: {
      type: String,
      enum: ["qr_code", "barcode", "rfid", "manual", "face_recognition"],
      default: "manual",
    },
    markedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // staff who marked it (null for self-service kiosk)
  },
  { timestamps: true }
);

attendanceSchema.index({ gym: 1, checkInTime: -1 });
attendanceSchema.index({ member: 1, checkInTime: -1 });

export default mongoose.model("Attendance", attendanceSchema);
