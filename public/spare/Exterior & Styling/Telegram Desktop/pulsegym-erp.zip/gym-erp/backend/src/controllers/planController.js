import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import Plan from "../models/Plan.js";

export const listPlans = asyncHandler(async (req, res) => {
  const filter = { gym: req.gymId };
  if (req.query.active === "true") filter.isActive = true;
  const plans = await Plan.find(filter).sort("-createdAt");
  res.status(200).json({ success: true, data: { plans } });
});

export const createPlan = asyncHandler(async (req, res) => {
  const plan = await Plan.create({ ...req.body, gym: req.gymId });
  res.status(201).json({ success: true, data: { plan } });
});

export const updatePlan = asyncHandler(async (req, res) => {
  const plan = await Plan.findOneAndUpdate({ _id: req.params.id, gym: req.gymId }, req.body, {
    new: true,
    runValidators: true,
  });
  if (!plan) throw new ApiError(404, "Plan not found.");
  res.status(200).json({ success: true, data: { plan } });
});

export const deletePlan = asyncHandler(async (req, res) => {
  const plan = await Plan.findOneAndUpdate(
    { _id: req.params.id, gym: req.gymId },
    { isActive: false },
    { new: true }
  );
  if (!plan) throw new ApiError(404, "Plan not found.");
  res.status(200).json({ success: true, message: "Plan deactivated." });
});
