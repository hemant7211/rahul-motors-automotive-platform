import mongoose from "mongoose";

const planSchema = new mongoose.Schema(
  {
    gym: { type: mongoose.Schema.Types.ObjectId, ref: "Gym", required: true },
    name: { type: String, required: true, trim: true },
    category: {
      type: String,
      enum: ["general", "personal_training", "crossfit", "yoga", "zumba", "cardio", "strength", "custom"],
      default: "general",
    },
    durationDays: { type: Number, required: true }, // e.g. 30, 90, 180, 365
    price: { type: Number, required: true },
    discountPercent: { type: Number, default: 0 },
    features: [{ type: String }],
    allowFreeze: { type: Boolean, default: true },
    maxFreezeDays: { type: Number, default: 15 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

planSchema.index({ gym: 1, isActive: 1 });

planSchema.virtual("finalPrice").get(function () {
  return Math.round(this.price - (this.price * this.discountPercent) / 100);
});
planSchema.set("toJSON", { virtuals: true });

export default mongoose.model("Plan", planSchema);
