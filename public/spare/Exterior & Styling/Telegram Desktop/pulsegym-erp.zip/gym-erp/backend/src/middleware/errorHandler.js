import ApiError from "../utils/ApiError.js";

// Converts known Mongoose/JWT error types into consistent ApiError responses
const normalizeError = (err) => {
  if (err instanceof ApiError) return err;

  if (err.name === "ValidationError") {
    const messages = Object.values(err.errors).map((e) => e.message);
    return new ApiError(400, "Validation failed", messages);
  }

  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0];
    return new ApiError(409, `${field ? field : "Field"} already exists.`);
  }

  if (err.name === "CastError") {
    return new ApiError(400, `Invalid value for ${err.path}: ${err.value}`);
  }

  return new ApiError(500, err.message || "Internal server error");
};

// eslint-disable-next-line no-unused-vars
const errorHandler = (err, req, res, next) => {
  const normalized = normalizeError(err);

  if (process.env.NODE_ENV !== "production" && !normalized.isOperational) {
    console.error(err);
  }

  res.status(normalized.statusCode || 500).json({
    success: false,
    message: normalized.message,
    details: normalized.details || undefined,
    stack: process.env.NODE_ENV === "development" ? err.stack : undefined,
  });
};

export const notFound = (req, res, next) => {
  next(new ApiError(404, `Route not found: ${req.originalUrl}`));
};

export default errorHandler;
